function appendToDisplay(value)
{
  document.getElementById('display').value+=value;
}

function calculate() 
{
  try {
    var result = eval(document.getElementById('display').value);
    document.getElementById('display').value = result;
  } catch (error) {
    document.getElementById('display').value = 'Error';
  }
}


function clearDisplay() 
{
  document.getElementById('display').value = '';
}

function backspace() 
{
  var currentExpression = document.getElementById('display').value;
  document.getElementById('display').value = currentExpression.slice(0, -1);
}